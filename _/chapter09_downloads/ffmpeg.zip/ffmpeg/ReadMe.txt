1. put custom-service-context and web-client-config-custom.xml files inside <alfresco_install>\tomcat\shared\classes\alfresco\extension.
2. put faces-config-custom file in tomcat<alfresco_install>\webapps\alfresco\WEB-INF folder.
3. replace mimetype-map file in <alfresco_install>\tomcat\webapps\alfresco\WEB-INF\classes\alfresco\mimetype.
4. put stv.jar file in <alfresco_install>\tomcat\webapps\alfresco\WEB-INF\lib
5. put transform-video.jsp file in <alfresco_install>\tomcat\webapps\alfresco\jsp\actions folder
6. put stv.properties in <alfresco_install>\tomcat\shared\classes\alfresco\messages folder
7. java-source folder contains the java files.