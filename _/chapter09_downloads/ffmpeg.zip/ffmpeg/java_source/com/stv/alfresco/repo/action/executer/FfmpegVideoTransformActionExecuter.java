package com.stv.alfresco.repo.action.executer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.repo.action.ParameterDefinitionImpl;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.action.ParameterDefinition;
import org.alfresco.service.cmr.dictionary.DataTypeDefinition;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NoTransformerException;

import com.stv.alfresco.repo.content.transform.FfmpegVideoContentTransformer;



public class FfmpegVideoTransformActionExecuter extends FfmpegTransformActionExecuter{

    /**
     * Action constants
     */
	public FfmpegVideoTransformActionExecuter()
	{	
	}
	public static final String NAME = "transform-video"; 
	public static final String PARAM_CONVERT_COMMAND = "convert-command";
	
	private FfmpegVideoContentTransformer stvVideoContentTransformer;
	
	/**
	 * Set the Video content transformer
	 * 
	 * @param VideoMagicContentTransformer: the Video content transformer
	 */
	public void setStvVideoContentTransformer(FfmpegVideoContentTransformer stvVideoContentTransformer) 
	{
		
		this.stvVideoContentTransformer = stvVideoContentTransformer;
	}
	
	/**
	 * Add parameter definitions
	 */
	@Override
	protected void addParameterDefinitions(List<ParameterDefinition> paramList) 
	{
		super.addParameterDefinitions(paramList);
		paramList.add(new ParameterDefinitionImpl(PARAM_CONVERT_COMMAND, DataTypeDefinition.TEXT, false, getParamDisplayLabel(PARAM_CONVERT_COMMAND)));
	}
	
	/**
	 * @see org.alfresco.repo.action.executer.TransformActionExecuter#doTransform(org.alfresco.service.cmr.action.Action, org.alfresco.service.cmr.repository.ContentReader, org.alfresco.service.cmr.repository.ContentWriter)
	 */
	protected void doTransform(Action ruleAction, ContentReader contentReader, ContentWriter contentWriter)
	{
        // check if the transformer is going to work, i.e. is available
        if (!this.stvVideoContentTransformer.isAvailable())
        {
            throw new NoTransformerException(contentReader.getMimetype(), contentWriter.getMimetype());
        }
		// Try and transform the content
        String convertCommand = (String)ruleAction.getParameterValue(PARAM_CONVERT_COMMAND);
        // create some options for the transform
        Map<String, Object> options = new HashMap<String, Object>(5);
        options.put(stvVideoContentTransformer.KEY_OPTIONS, convertCommand);
        
        this.stvVideoContentTransformer.transform(contentReader, contentWriter, options);    
	}
}
