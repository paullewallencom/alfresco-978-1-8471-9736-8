package com.stv.alfresco.repo.content;

import org.alfresco.repo.content.ContentStore;
import org.alfresco.repo.content.RoutingContentService;
import org.alfresco.repo.content.filestore.FileContentStore;
import org.alfresco.util.TempFileProvider;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.stv.alfresco.repo.content.transform.FfmpegVideoContentTransformer;

public class FfmpegRoutingContentService extends RoutingContentService
{
    private static Log logger = LogFactory.getLog(FfmpegRoutingContentService.class);
    private ContentStore tempStore;
    private FfmpegVideoContentTransformer stvVideoContentTransformer;
    
    public FfmpegRoutingContentService()
    {
        this.tempStore = new FileContentStore(TempFileProvider.getTempDir().getAbsolutePath());
    }
 // To fetch the value from the property declared in the xml file for the bean StudiocomVideoContentTransformer
    public void setStvVideoContentTransformer(FfmpegVideoContentTransformer stvVideoContentTransformer) 
    {
        this.stvVideoContentTransformer = stvVideoContentTransformer;
    }
}

