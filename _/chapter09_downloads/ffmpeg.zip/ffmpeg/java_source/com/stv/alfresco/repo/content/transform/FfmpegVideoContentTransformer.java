package com.stv.alfresco.repo.content.transform;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.error.AlfrescoRuntimeException;
import org.alfresco.service.cmr.repository.ContentIOException;
import org.alfresco.util.exec.RuntimeExec;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FfmpegVideoContentTransformer extends FfmpegAbstractVideoContentTransformer
{
    /** the command options, such as <b>--resize</b>, etc. */
    public static final String KEY_OPTIONS = "options";
    /** source variable name */
    public static final String VAR_OPTIONS = "options";
    /** source variable name */
    public static final String VAR_SOURCE = "source";
    /** target variable name */
    public static final String VAR_TARGET = "target";
    
    private static final Log logger = LogFactory.getLog(FfmpegVideoContentTransformer.class);

    /** the system command executer */
    private RuntimeExec executer;
    
    public FfmpegVideoContentTransformer()
    {
    }
    
    public void setExecuter(RuntimeExec executer)
    {
        this.executer = executer;
    }

    public void init()
    {
        if (executer == null)
        {
            throw new AlfrescoRuntimeException("System runtime executer not set");
        }
        super.init();
    }
    
    /**
     * Transform the video content from the source file to the target file
     */
    protected void transformInternal(File sourceFile, File targetFile, Map options) throws Exception
    {
    	//System.out.println("Inside transformInternal of StarVideoContentTransformer");
        Map<String, String> properties = new HashMap<String, String>(5);
        // set properties
        properties.put(VAR_SOURCE, sourceFile.getAbsolutePath());
        properties.put(KEY_OPTIONS, (String) options.get(KEY_OPTIONS));
        properties.put(VAR_TARGET, targetFile.getAbsolutePath());
        
        // execute the statement
        RuntimeExec.ExecutionResult result = executer.execute(properties);
                
        if (result.getExitValue() != 0 && result.getStdErr() != null && result.getStdErr().length() > 0)
        { 
            throw new ContentIOException("Failed to perform Video transformation: \n" + result);
        }
        // success
        if (logger.isDebugEnabled())
        {   
            logger.debug("Video executed successfully: \n" + executer);
        }
    }
}
