package com.stv.alfresco.web.bean.actions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.alfresco.config.Config;
import org.alfresco.config.ConfigElement;
import org.alfresco.config.ConfigService;
import org.alfresco.web.app.Application;
import org.alfresco.web.bean.actions.BaseActionWizard;
import org.alfresco.web.data.IDataContainer;
import org.alfresco.web.data.QuickSort;
import org.alfresco.web.ui.common.Utils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public abstract class FfmpegBaseActionWizard extends BaseActionWizard
{
	   protected List<SelectItem> videoTransformers;
	   private static final Log logger = LogFactory.getLog(FfmpegBaseActionWizard.class);
	   
	   // ------------------------------------------------------------------------------
	   // Wizard implementation
	   
	   /**
	    * Returns the image transformers that are available
	    * 
	    * @return List of SelectItem objects representing the available image transformers
	    */
	   
	   public List<SelectItem> getVideoTransformers()
	   {
	      if (this.videoTransformers == null)
	      {    
	         ConfigService svc = Application.getConfigService(FacesContext.getCurrentInstance());
	         Config wizardCfg = svc.getConfig("Action Wizards");
	         if (wizardCfg != null)
	         {
	            ConfigElement transformersCfg = wizardCfg.getConfigElement("video-transformers");
	            if (transformersCfg != null)
	            {
	               FacesContext context = FacesContext.getCurrentInstance();
	               //Map<String, String> mimeTypes = this.mimetypeService.getDisplaysByMimetype();
	               Map<String, String> mimeTypes = this.getMimetypeService().getDisplaysByMimetype();
	               this.videoTransformers = new ArrayList<SelectItem>();
	               for (ConfigElement child : transformersCfg.getChildren())
	               {
	                  String id = child.getAttribute("name");
	                  
	                  // try and get the display label from config
	                  String label = Utils.getDisplayLabel(context, child);

	                  // if there wasn't a client based label get it from the mime type service
	                  if (label == null)
	                  {
	                     label = mimeTypes.get(id);        
	                  }

	                  this.videoTransformers.add(new SelectItem(id, label));
	               }
	               
	               // make sure the list is sorted by the label
	               QuickSort sorter = new QuickSort(this.videoTransformers, "label", true, IDataContainer.SORT_CASEINSENSITIVE);
	               sorter.sort();
	            }
	            else
	            {
	               logger.warn("Could not find 'video-transformers' configuration element");
	            }
	         }
	         else
	         {
	            logger.warn("Could not find 'Action Wizards' configuration section");
	         }
	      }
	      return this.videoTransformers;
	   }
}
