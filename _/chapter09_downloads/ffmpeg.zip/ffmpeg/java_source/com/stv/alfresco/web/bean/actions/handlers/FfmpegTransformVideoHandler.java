package com.stv.alfresco.web.bean.actions.handlers;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.alfresco.config.Config;
import org.alfresco.config.ConfigElement;
import org.alfresco.config.ConfigService;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.action.executer.TransformActionExecuter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.web.app.Application;
import org.alfresco.web.bean.actions.handlers.BaseActionHandler;
import org.alfresco.web.bean.repository.Repository;
import org.alfresco.web.bean.wizard.IWizardBean;
import org.alfresco.web.data.IDataContainer;
import org.alfresco.web.data.QuickSort;
import org.alfresco.web.ui.common.Utils;

import com.stv.alfresco.repo.action.executer.FfmpegVideoTransformActionExecuter;
import com.stv.alfresco.web.app.FfmpegApplication;
import com.stv.alfresco.web.bean.actions.FfmpegBaseActionWizard;


/**
 * Action handler for the "transform-video" action.
 * @author pallika
 *
 */
public class FfmpegTransformVideoHandler extends BaseActionHandler{

	protected static final String PROP_VIDEO_TRANSFORMER = "videoTransformer";
	protected static final String PROP_TRANSFORM_OPTIONS = "transformOptions";
	
	 protected List<SelectItem> videoTransformers;
	
	public String generateSummary(FacesContext context, IWizardBean wizard, Map<String, Serializable> actionProps) {
		String label = null;
	      NodeRef space = (NodeRef)actionProps.get(PROP_DESTINATION);
	      String name = Repository.getNameForNode(
	            Repository.getServiceRegistry(context).getNodeService(), space);
	      String transformer = (String)actionProps.get(PROP_VIDEO_TRANSFORMER);
	      String option = (String)actionProps.get(PROP_TRANSFORM_OPTIONS);
	      
	      // find the label used by looking through the SelectItem list
	      for (SelectItem item : ((FfmpegBaseActionWizard)wizard).getVideoTransformers())
	      {
	         if (item.getValue().equals(transformer))
	         {
	            label = item.getLabel();
	            break;
	         }
	      }
	      return MessageFormat.format(FfmpegApplication.getMessage(context, "action_transform_video"),
	            new Object[] {name, label, option});
	}

	public String getJSPPath() {
		return getJSPPath(FfmpegVideoTransformActionExecuter.NAME);
	}

	public void prepareForEdit(Map<String, Serializable> actionProps, Map<String, Serializable> repoProps) {
		String transformer = (String)repoProps.get(TransformActionExecuter.PARAM_MIME_TYPE);
	      actionProps.put(PROP_VIDEO_TRANSFORMER, transformer);
	      
	      String options = (String)repoProps.get(FfmpegVideoTransformActionExecuter.PARAM_CONVERT_COMMAND);
	      actionProps.put(PROP_TRANSFORM_OPTIONS, options != null ? options : "");
	      
	      NodeRef destNodeRef = (NodeRef)repoProps.get(FfmpegVideoTransformActionExecuter.PARAM_DESTINATION_FOLDER);
	      actionProps.put(PROP_DESTINATION, destNodeRef);
		
	}

	public void prepareForSave(Map<String, Serializable> actionProps, Map<String, Serializable> repoProps) {
//		 add the transformer to use
	      repoProps.put(FfmpegVideoTransformActionExecuter.PARAM_MIME_TYPE,
	            actionProps.get(PROP_VIDEO_TRANSFORMER));
	      
	      // add the options
	      repoProps.put(FfmpegVideoTransformActionExecuter.PARAM_CONVERT_COMMAND, 
	            actionProps.get(PROP_TRANSFORM_OPTIONS));
	      
	      // add the destination space id to the action properties
	      NodeRef destNodeRef = (NodeRef)actionProps.get(PROP_DESTINATION);
	      repoProps.put(FfmpegVideoTransformActionExecuter.PARAM_DESTINATION_FOLDER, destNodeRef);
	      
	      // add the type and name of the association to create when the copy
	      // is performed
	      repoProps.put(TransformActionExecuter.PARAM_ASSOC_TYPE_QNAME, 
	            ContentModel.ASSOC_CONTAINS);
	      repoProps.put(TransformActionExecuter.PARAM_ASSOC_QNAME, 
	            QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, "copy"));
		
	}
}
