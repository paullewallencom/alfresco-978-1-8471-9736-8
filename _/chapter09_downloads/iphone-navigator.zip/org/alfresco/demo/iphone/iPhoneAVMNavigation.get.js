if ((args.storeid) && (args.storeid != "")) {

	var root = avm.lookupStoreRoot(args.storeid);
	
	  if (root != null)
	 {
		var node = avm.lookupNode(root.path+"/ROOT");
		
		model.node = node;
		model.path = node.path;
	 }
	 else
	 {
		model.node = null;
	 }
	 
	
	model.previewurl = avm.websiteStagingUrl(args.storeid);
	

}


if ((args.p) && (args.p != ""))
{
  var path = args.p;

  var node = avm.lookupNode(path);
 
  if (node != null)
 {
	model.node = node;
	model.path = node.path;
	model.previewurl = args.previewurl;
 }
 else
 {
	model.node = null;
 }

}
