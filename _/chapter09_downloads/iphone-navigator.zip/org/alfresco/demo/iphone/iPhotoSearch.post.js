var q = (args.keyword == null) ? "***" : args.keyword;

var nodes = new Array();

if ( q.length >= 3) {

	nodes = search.luceneSearch("(TEXT:"+ q+")");

}

model.results = nodes;
